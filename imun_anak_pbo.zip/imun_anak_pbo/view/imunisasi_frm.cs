﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imun_anak_pbo.view
{
    public partial class imunisasi_frm: Form
    {
        public imunisasi_frm()
        {
            InitializeComponent();
        }
    }
}
